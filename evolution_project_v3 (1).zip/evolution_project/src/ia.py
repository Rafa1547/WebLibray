import numpy as np


class NeuralNetwork:
    def __init__(self, input_size, hidden_size, output_size):
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        
        # Inicialização de pesos e bias com valores aleatórios
        self.w1 = np.random.randn(self.input_size, self.hidden_size)
        self.b1 = np.zeros((1, self.hidden_size))
        self.w2 = np.random.randn(self.hidden_size, self.output_size)
        self.b2 = np.zeros((1, self.output_size))

    def predict(self, inputs):
        # Forward propagation
        z1 = np.dot(inputs, self.w1) + self.b1
        a1 = np.tanh(z1)  # Função de ativação tanh para as camadas ocultas
        z2 = np.dot(a1, self.w2) + self.b2
        # Saída entre -1 e 1 (ideal para controle de movimento)
        return np.tanh(z2)

    def get_weights(self):
        return [self.w1, self.b1, self.w2, self.b2]

    def set_weights(self, weights):
        self.w1, self.b1, self.w2, self.b2 = weights

    def save(self, filepath):
        """Guarda os pesos e a arquitetura da rede num ficheiro .npz."""
        np.savez(
            filepath,
            w1=self.w1, b1=self.b1, w2=self.w2, b2=self.b2,
            input_size=self.input_size,
            hidden_size=self.hidden_size,
            output_size=self.output_size,
        )

    @classmethod
    def load(cls, filepath):
        """Cria uma NeuralNetwork a partir de um ficheiro .npz guardado com save()."""
        data = np.load(filepath)
        net = cls(int(data["input_size"]), int(data["hidden_size"]), int(data["output_size"]))
        net.w1 = data["w1"]
        net.b1 = data["b1"]
        net.w2 = data["w2"]
        net.b2 = data["b2"]
        return net

class GeneticAlgorithm:
    @staticmethod
    def mutate(weights, mutation_rate=0.1):
        new_weights = []
        for w in weights:
            mutation = np.random.randn(*w.shape) * mutation_rate
            mask = np.random.rand(*w.shape) < mutation_rate
            new_w = w.copy()
            new_w[mask] += mutation[mask]
            new_weights.append(new_w)
        return new_weights

    @staticmethod
    def crossover(parent1_weights, parent2_weights):
        child_weights = []
        for w1, w2 in zip(parent1_weights, parent2_weights):
            mask = np.random.rand(*w1.shape) > 0.5
            child_w = np.where(mask, w1, w2)
            child_weights.append(child_w)
        return child_weights

import matplotlib.pyplot as plt


class StatsTracker:
    def __init__(self):
        self.generations = []
        self.avg_fitness = []
        self.max_fitness = []
        self.level_changes = []  # lista de (geração, nome_do_nível)

    def add_data(self, gen, avg, max_f):
        self.generations.append(gen)
        self.avg_fitness.append(avg)
        self.max_fitness.append(max_f)

    def add_level_change(self, gen, level_name):
        self.level_changes.append((gen, level_name))

    def plot_stats(self):
        plt.figure(figsize=(10, 5))
        plt.plot(self.generations, self.avg_fitness, label='Fitness Média', color='blue')
        plt.plot(self.generations, self.max_fitness, label='Fitness Máxima', color='red')

        for gen, name in self.level_changes:
            plt.axvline(x=gen, color='green', linestyle='--', alpha=0.6)
            plt.text(gen, plt.ylim()[1] * 0.95, name, rotation=90, fontsize=8, va='top', color='green')

        plt.title('Evolução da População ao Longo das Gerações')
        plt.xlabel('Geração')
        plt.ylabel('Fitness')
        plt.legend()
        plt.grid(True)
        plt.savefig('evolution_stats.png')
        plt.close()
        print("Gráfico de estatísticas guardado como 'evolution_stats.png'")

"""
Definição dos níveis de dificuldade progressiva.

Cada nível especifica:
- target: posição do alvo final (x, y)
- checkpoints: lista ordenada de pontos de passagem que dão fitness parcial
- obstacles: lista de obstáculos, estáticos ou móveis
- success_threshold: percentagem mínima de sucesso da geração para avançar
  automaticamente para o nível seguinte (1.1 = nunca avança, é o nível final)
"""

LEVELS = [
    {
        "name": "Nível 1 - Corredor Simples",
        "target": (400, 50),
        "checkpoints": [(400, 350)],
        "obstacles": [
            {"x": 150, "y": 250, "w": 500, "h": 20},
        ],
        "success_threshold": 0.5,
    },
    {
        "name": "Nível 2 - Zigue-Zague",
        "target": (400, 50),
        "checkpoints": [(650, 420), (150, 260)],
        "obstacles": [
            {"x": 0, "y": 180, "w": 500, "h": 20},
            {"x": 300, "y": 360, "w": 500, "h": 20},
        ],
        "success_threshold": 0.5,
    },
    {
        "name": "Nível 3 - Obstáculos Móveis",
        "target": (400, 50),
        "checkpoints": [(400, 380), (400, 200)],
        "obstacles": [
            {"x": 150, "y": 300, "w": 120, "h": 20, "moving": True, "axis": "x", "speed": 2.0, "range": 350},
            {"x": 550, "y": 150, "w": 120, "h": 20, "moving": True, "axis": "x", "speed": 1.5, "range": 300},
        ],
        # último nível: 1.1 garante que nunca avança automaticamente
        "success_threshold": 1.1,
    },
]

import math
import random

import numpy as np
import pygame

from src.ia import NeuralNetwork
from src.levels import LEVELS

# Configurações Globais
WIDTH, HEIGHT = 800, 600
AGENT_RADIUS = 8
TARGET_RADIUS = 15
CHECKPOINT_RADIUS = 20
MAX_STEPS = 500

# Configuração dos sensores (raycasting)
NUM_RAYS = 8
RAY_MAX_DIST = 180
RAY_ANGLES = [i * (2 * math.pi / NUM_RAYS) for i in range(NUM_RAYS)]

# Arquitetura da rede: posição(2) + velocidade(2) + direção ao alvo(2) + raios(NUM_RAYS)
INPUT_SIZE = 6 + NUM_RAYS
HIDDEN_SIZE = 16
OUTPUT_SIZE = 2


def cast_ray(start, angle, max_dist, obstacles):
    """Lança um raio a partir de 'start' na direção 'angle' e devolve a
    distância até ao primeiro obstáculo ou parede que encontrar."""
    start = (float(start[0]), float(start[1]))
    dx, dy = math.cos(angle), math.sin(angle)
    end = (start[0] + dx * max_dist, start[1] + dy * max_dist)
    closest = max_dist

    for obs in obstacles:
        clipped = obs.rect.clipline(start, end)
        if clipped:
            (ex, ey), _ = clipped
            d = math.hypot(ex - start[0], ey - start[1])
            if d < closest:
                closest = d

    # Distância até ao limite do ecrã (as "paredes" do mundo)
    t_candidates = []
    if dx > 1e-6:
        t_candidates.append((WIDTH - start[0]) / dx)
    elif dx < -1e-6:
        t_candidates.append((0 - start[0]) / dx)
    if dy > 1e-6:
        t_candidates.append((HEIGHT - start[1]) / dy)
    elif dy < -1e-6:
        t_candidates.append((0 - start[1]) / dy)

    valid_t = [t for t in t_candidates if t > 0]
    if valid_t:
        t_wall = min(valid_t)
        if t_wall < closest:
            closest = t_wall

    return closest


class Obstacle:
    def __init__(self, x, y, w, h, moving=False, axis="x", speed=0.0, range_=0.0):
        self.start_x = x
        self.start_y = y
        self.rect = pygame.Rect(x, y, w, h)
        self.moving = moving
        self.axis = axis
        self.speed = speed
        self.range = range_
        # fase aleatória para que obstáculos não fiquem todos sincronizados
        self.phase = random.uniform(0, 2 * math.pi)

    def update(self):
        if not self.moving:
            return
        t = pygame.time.get_ticks() * 0.001
        offset = math.sin(t * self.speed + self.phase) * (self.range / 2)
        if self.axis == "x":
            self.rect.x = int(self.start_x + offset)
        else:
            self.rect.y = int(self.start_y + offset)

    def draw(self, screen):
        color = (180, 120, 40) if self.moving else (100, 100, 100)
        pygame.draw.rect(screen, color, self.rect)
        pygame.draw.rect(screen, (220, 220, 220), self.rect, 2)


class Agent:
    def __init__(self, waypoints, brain=None):
        self.pos = np.array([WIDTH // 2, HEIGHT - 50], dtype=float)
        self.vel = np.array([0, 0], dtype=float)
        self.acc = np.array([0, 0], dtype=float)
        self.alive = True
        self.reached_target = False
        self.hit_obstacle = False
        self.fitness = 0
        self.steps = 0

        # waypoints = checkpoints do nível + alvo final (último elemento)
        self.waypoints = waypoints
        self.target_index = 0
        self.checkpoints_reached = 0

        self.brain = brain if brain else NeuralNetwork(INPUT_SIZE, HIDDEN_SIZE, OUTPUT_SIZE)

    def current_target(self):
        return self.waypoints[self.target_index]

    def is_on_final_target(self):
        return self.target_index == len(self.waypoints) - 1

    def apply_force(self, force):
        self.acc += force

    def sense_obstacles(self, obstacles):
        """Sensores de distância (raycasting): 1.0 = caminho livre, 0.0 = a tocar."""
        return [cast_ray(self.pos, a, RAY_MAX_DIST, obstacles) / RAY_MAX_DIST for a in RAY_ANGLES]

    def update(self, obstacles):
        if not self.alive or self.reached_target:
            return

        for obs in obstacles:
            if obs.rect.collidepoint(self.pos[0], self.pos[1]):
                self.hit_obstacle = True
                self.alive = False
                return

        target = self.current_target()
        dist_to_target = target - self.pos
        ray_readings = self.sense_obstacles(obstacles)

        inputs = np.array([
            self.pos[0] / WIDTH,
            self.pos[1] / HEIGHT,
            dist_to_target[0] / WIDTH,
            dist_to_target[1] / HEIGHT,
            self.vel[0] / 5.0,
            self.vel[1] / 5.0,
            *ray_readings,
        ]).reshape(1, -1)

        action = self.brain.predict(inputs)
        self.apply_force(action[0] * 0.6)

        # Física
        self.vel += self.acc
        self.pos += self.vel
        self.acc *= 0
        self.steps += 1

        speed = np.linalg.norm(self.vel)
        if speed > 5:
            self.vel = (self.vel / speed) * 5

        if self.pos[0] < 0 or self.pos[0] > WIDTH or self.pos[1] < 0 or self.pos[1] > HEIGHT:
            self.alive = False

        # Checkpoint atingido ou alvo final atingido
        d = np.linalg.norm(self.pos - target)
        radius = TARGET_RADIUS if self.is_on_final_target() else CHECKPOINT_RADIUS
        if d < radius:
            if self.is_on_final_target():
                self.reached_target = True
                self.alive = False
            else:
                self.target_index += 1
                self.checkpoints_reached += 1

        if self.steps >= MAX_STEPS:
            self.alive = False

    def calculate_fitness(self, final_target_pos):
        d = np.linalg.norm(self.pos - final_target_pos)
        self.fitness = 1.0 / (d + 1.0)

        # Bónus por cada checkpoint intermédio alcançado
        self.fitness += self.checkpoints_reached * 2.0

        if self.reached_target:
            self.fitness *= 10.0
            self.fitness += (MAX_STEPS - self.steps) / MAX_STEPS

        if self.hit_obstacle:
            self.fitness *= 0.1

        if not self.alive and not self.reached_target:
            self.fitness *= 0.8

    def draw(self, screen):
        if self.reached_target:
            color = (50, 255, 50)
        elif self.hit_obstacle:
            color = (150, 0, 0)
        elif not self.alive:
            color = (100, 100, 100)
        else:
            color = (255, 255, 255)

        pygame.draw.circle(screen, color, (int(self.pos[0]), int(self.pos[1])), AGENT_RADIUS)

        if self.reached_target:
            # Auréola dourada para destacar quem chegou ao alvo
            pygame.draw.circle(
                screen, (255, 215, 0), (int(self.pos[0]), int(self.pos[1])), AGENT_RADIUS + 5, 2
            )

        if self.alive:
            end_pos = self.pos + self.vel * 3
            pygame.draw.line(screen, (200, 200, 200), self.pos, end_pos, 1)

    def draw_rays(self, screen, obstacles):
        """Desenha os sensores deste agente (usado para depuração/demonstração)."""
        for angle in RAY_ANGLES:
            dist = cast_ray(self.pos, angle, RAY_MAX_DIST, obstacles)
            end = (self.pos[0] + math.cos(angle) * dist, self.pos[1] + math.sin(angle) * dist)
            close = dist < RAY_MAX_DIST * 0.3
            color = (255, 80, 80) if close else (80, 200, 255)
            pygame.draw.line(screen, color, self.pos, end, 1)


class Simulation:
    def __init__(self, population_size=50, level_index=0):
        self.pop_size = population_size
        self.generation = 1
        self.show_rays = False
        self.level_index = level_index
        self.level_name = ""
        self.target = None
        self.checkpoints = []
        self.obstacles = []
        self.agents = []

        # Hall da Fama: guarda o melhor cérebro que já venceu, para que a
        # população nunca "esqueça" o que já aprendeu, mesmo com azar.
        self.hall_of_fame_brain = None
        self.hall_of_fame_fitness = -1.0

        self.load_level(level_index)
        self.reset_agents()

    def load_level(self, level_index):
        """Carrega a configuração (alvo, checkpoints, obstáculos) de um nível.
        Não recria os agentes — usar reset_agents() para isso."""
        level = LEVELS[level_index]
        self.level_index = level_index
        self.level_name = level["name"]
        self.target = np.array(level["target"], dtype=float)
        self.checkpoints = [np.array(cp, dtype=float) for cp in level["checkpoints"]]
        self.obstacles = [
            Obstacle(
                o["x"], o["y"], o["w"], o["h"],
                moving=o.get("moving", False),
                axis=o.get("axis", "x"),
                speed=o.get("speed", 0.0),
                range_=o.get("range", 0.0),
            )
            for o in level["obstacles"]
        ]

    def waypoints(self):
        return self.checkpoints + [self.target]

    def reset_agents(self, brains=None):
        """Recria os agentes no nível atual. Se 'brains' for fornecido, cada
        agente novo herda esse cérebro (usado para passar de geração/nível)."""
        wp = self.waypoints()
        if brains is None:
            self.agents = [Agent(wp) for _ in range(self.pop_size)]
        else:
            self.agents = [Agent(wp, brain=b) for b in brains]

    def all_dead(self):
        return all(not a.alive for a in self.agents)

    def success_rate(self):
        if not self.agents:
            return 0.0
        successes = sum(1 for a in self.agents if a.reached_target)
        return successes / len(self.agents)

    def win_count(self):
        return sum(1 for a in self.agents if a.reached_target)

    def update_hall_of_fame(self, agents):
        """Verifica se algum agente bateu o recorde de sempre. Devolve True
        se houve um novo recorde (útil para festejar/avisar na consola)."""
        new_record = False
        for agent in agents:
            if agent.reached_target and agent.fitness > self.hall_of_fame_fitness:
                self.hall_of_fame_fitness = agent.fitness
                self.hall_of_fame_brain = agent.brain
                new_record = True
        return new_record

    def update(self):
        for obs in self.obstacles:
            obs.update()
        for agent in self.agents:
            agent.update(self.obstacles)

    def draw(self, screen):
        for cp in self.checkpoints:
            pygame.draw.circle(screen, (255, 200, 0), (int(cp[0]), int(cp[1])), CHECKPOINT_RADIUS, 2)

        pygame.draw.circle(screen, (0, 100, 255), (int(self.target[0]), int(self.target[1])), TARGET_RADIUS + 5, 2)
        pygame.draw.circle(screen, (0, 0, 255), (int(self.target[0]), int(self.target[1])), TARGET_RADIUS)

        for obs in self.obstacles:
            obs.draw(screen)

        for agent in self.agents:
            agent.draw(screen)

        if self.show_rays:
            alive_agents = [a for a in self.agents if a.alive]
            if alive_agents:
                best = max(alive_agents, key=lambda a: a.fitness)
                best.draw_rays(screen, self.obstacles)
